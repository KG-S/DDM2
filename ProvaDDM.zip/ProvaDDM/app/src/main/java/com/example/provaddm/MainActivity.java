package com.example.provaddm;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button btnAdd;
    private ListView listaCompra;
    private ArrayList<Compra> itens = new ArrayList<>();


    private AdapterContatos adaptador;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd = findViewById(R.id.btnAdd);
        listaCompra= findViewById(R.id.listaCompra);

        btnAdd.setOnClickListener(new AddButton());



        // configurando a lista:

        // criando adaptador
        adaptador = new AdapterContatos( this, itens);


        // configurar a lista para utilizar este objeto adaptador
        listaCompra.setAdapter( adaptador );

        // configurar a lista com o escutador de cliques comuns
        listaCompra.setOnItemClickListener( new EscutadorLista() );

        // configurar a lista para aceitar cliques longos
        listaCompra.setLongClickable( true );

        // configurar a lista com o escutador de cliques longos
        listaCompra.setOnItemLongClickListener( new EscutadorLista() );
    }

    private class AddButton implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent i = new Intent(getApplicationContext(), MainActivity2.class);
            startActivity(i);
        }

    }


    private class EscutadorLista implements AdapterView.OnItemClickListener,
            AdapterView.OnItemLongClickListener {

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            if ( itens.get(i).getComprado() != "") {
                Toast.makeText(MainActivity.this, "Clique comum: " + itens.get(i),
                        Toast.LENGTH_SHORT).show();
                itens.get(i).setComprado("COMPRADO");
            } else {
                itens.get(i).setComprado("COMPRADO");
                adaptador.notifyDataSetChanged();


            }



        }


        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

            // remover o item de índice i do ArrayList
            itens.remove(i);

            // avisar o adapter que o arraylist mudou
            adaptador.notifyDataSetChanged();

            // mensagem informativa
            Toast.makeText(MainActivity.this, "Item apagado!", Toast.LENGTH_LONG).show();

            // receita de bolo: retornar true, indicando que o evento foi tratado.
            // se retornar false, vai querer tratar clique comum também
            return true;
        }
    }

}