package com.example.provaddm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class AdapterContatos extends ArrayAdapter<Compra> {

    // atributos:

    // contexto
    private Context context;

    // arraylist de objetos do tipo Contato
    private ArrayList<Compra> itens;

    public AdapterContatos(Context context, ArrayList<Compra> itens) {

        // super:
        // contexto, layout do item da lista, arraylist com os itens
        super(context, R.layout.item_lista, itens);

        // guarda o contexto no atributo correspondente
        this.context = context;

        // guarda o arraylist com os itens no atributo correspondente
        this.itens = itens;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // recuperar um objeto "inflador” de layouts...
        LayoutInflater li = LayoutInflater.from(parent.getContext());

        // "inflando" o xml do item da lista, gerando sua visualização (view)
        View itemView = li.inflate(R.layout.item_lista, parent, false);

        // pegando os objetos gráficos dentro do xml do item da lista
        TextView lblNome = itemView.findViewById(R.id.lblNome);
        TextView lblMarca = itemView.findViewById(R.id.lblMarca);
        TextView lblQuant = itemView.findViewById(R.id.lblQuant);
        TextView lblComprado = itemView.findViewById(R.id.lblComprado);




        // colocando dados neste item
        // o objeto esta no índice 'position'
        lblNome.setText(itens.get(position).getNome());
        lblMarca.setText(itens.get(position).getMarca());
        lblQuant.setText(itens.get(position).getQuant());
        lblComprado.setText(itens.get(position).getComprado());





        // a view do item da lista está montada!!
        // é só devolver
        return itemView;
    }

    public void updateItens(ArrayList<Compra> itens) {
        this.itens = itens;

    }

}