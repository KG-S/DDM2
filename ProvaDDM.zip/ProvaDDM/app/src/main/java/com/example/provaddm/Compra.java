package com.example.provaddm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Compra extends AppCompatActivity {

    private String nome;
    private String marca;
    private String quant;

    private String comprado;


    public Compra(String nome, String marca, String quant ) {

        this.nome = nome;
        this.marca = marca;
        this.quant = quant;
        this.comprado = "";

    }

    public String getNome() {

        return nome;
    }

    public String getMarca() {

        return marca;
    }

    public String getQuant() {

        return quant;
    }
    public String getComprado(){

        return comprado;
    }

    public void setComprado(String comprado) {
        this.comprado = comprado;
    }
}


