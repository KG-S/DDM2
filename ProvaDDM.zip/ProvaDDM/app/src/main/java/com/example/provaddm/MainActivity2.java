package com.example.provaddm;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    // atributos referentes aos objetos gráficos
    private EditText txtNome;
    private EditText txtMarca;

    private EditText txtQuant;

    private Button btnAdiciona;
    private ListView listaCompra;

    private ArrayList<Compra> itens = new ArrayList<>();

    // adapter da lista
    private AdapterContatos adaptador;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ligando atributos com os ID dos objetos na interface
        txtNome = findViewById( R.id.txtNome );
        txtMarca = findViewById( R.id.txtMarca);
        txtQuant = findViewById( R.id.txtQuant);
        btnAdiciona = findViewById( R.id.btnAdiciona );
        listaCompra= findViewById( R.id.listaCompra );

        // criando e associando escutador do botão
        btnAdiciona.setOnClickListener( new EscutadorBotao() );

        // configurando a lista:


    }
    private class EscutadorBotao implements View.OnClickListener{


        @Override
        public void onClick(View view) {

            // variaveis para auxilio
            String nome;
            String marca;
            String quant;


            // pegando dados nas caixas de texto
            nome = txtNome.getText().toString();
            marca = txtMarca.getText().toString();
            quant = txtQuant.getText().toString();


            // criando objeto Contato
            Compra c = new Compra( nome, marca, quant);

            // inserindo no ArrayList
            itens.add( c );

            // avisando o adapter que os dados foram atualizados
            adaptador.notifyDataSetChanged();

            // "limpando" a interface, para a próxima digitação
            txtNome.setText("");
            txtMarca.setText("");
            txtQuant.setText("");

        }


    }
}