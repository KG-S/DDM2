package com.example.hogward;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {

    // atributos referentes aos objetos gráficos
    private EditText txtNome;
    private EditText txtPreco;

    private Button btnAdiciona;
    private ListView listaMateriais;

    // ArrayList de contatos
    private ArrayList<Material> materiais = new ArrayList<>();

    // adapter da lista
    private AdapterContatos adaptador;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ligando atributos com os ID dos objetos na interface
        txtNome = findViewById( R.id.txtNome );
        txtPreco = findViewById( R.id.txtPreco);
        btnAdiciona = findViewById( R.id.btnAdiciona );
        listaMateriais= findViewById( R.id.listaMateriais );

        // criando e associando escutador do botão
        btnAdiciona.setOnClickListener( new EscutadorBotao() );

        // configurando a lista:

        // criando adaptador
        adaptador = new AdapterContatos( this, materiais);


        // configurar a lista para utilizar este objeto adaptador
        listaMateriais.setAdapter( adaptador );

        // configurar a lista com o escutador de cliques comuns
        listaMateriais.setOnItemClickListener( new EscutadorLista() );

        // configurar a lista para aceitar cliques longos
        listaMateriais.setLongClickable( true );

        // configurar a lista com o escutador de cliques longos
        listaMateriais.setOnItemLongClickListener( new EscutadorLista() );
    }
    private class EscutadorBotao implements View.OnClickListener{


        @Override
        public void onClick(View view) {

            // variaveis para auxilio
            String nome;
            String preco;


            // pegando dados nas caixas de texto
            nome = txtNome.getText().toString();
            preco = txtPreco.getText().toString();


            // criando objeto Contato
            Material c = new Material( nome, preco);

            // inserindo no ArrayList
            materiais.add( c );

            // avisando o adapter que os dados foram atualizados
            adaptador.notifyDataSetChanged();

            // "limpando" a interface, para a próxima digitação
            txtNome.setText("");
            txtPreco.setText("");

        }


    }

    private class EscutadorLista implements AdapterView.OnItemClickListener,
            AdapterView.OnItemLongClickListener {

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            // O parâmetro i é o número do item clicado ...
            Toast.makeText(MainActivity.this, "Clique comum: " + materiais.get(i),
                    Toast.LENGTH_SHORT).show();
        }


        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

            // remover o item de índice i do ArrayList
            materiais.remove(i);

            // avisar o adapter que o arraylist mudou
            adaptador.notifyDataSetChanged();

            // mensagem informativa
            Toast.makeText(MainActivity.this, "Item apagado!", Toast.LENGTH_LONG).show();

            // receita de bolo: retornar true, indicando que o evento foi tratado.
            // se retornar false, vai querer tratar clique comum também
            return true;
        }
    }

    // classe interna do escutador do clique no botão adiciona

}