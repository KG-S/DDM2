package com.example.hogward;

import android.view.View;
import android.widget.AdapterView;

public interface EscutadorBotao {
    void onItemClick(AdapterView<?> adapterView, View view, int i, long l);

    boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l);
}
