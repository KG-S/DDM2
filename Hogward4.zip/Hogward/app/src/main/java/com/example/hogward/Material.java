package com.example.hogward;

public class Material {


        private String nome;
        private String preco;


        public Material(String nome, String preco ) {

            this.nome = nome;
            this.preco = preco;

        }

        public String getNome() {

            return nome;
        }

        public String getPreco() {

            return preco;
        }




    }

